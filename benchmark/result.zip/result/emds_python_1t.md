# Pairwise EMD Benchmark � Python (n_jobs=1)

| Split | Setup | Time (s) | Pairs |
|---|---|---|---|
| 10v90 | EF_POT_Euclidean_norm | 3.69 | 900 |
| 10v90 | EF_POT_Euclidean_unnorm | 3.26 | 900 |
| 10v90 | EF_POT_YPhi_norm | 4.47 | 900 |
| 10v90 | Wass_Euclidean_norm | 2.07 | 900 |
| 10v90 | Wass_Euclidean_unnorm | 2.82 | 900 |
| 10v90 | Wass_YPhi_norm | 1.99 | 900 |
| 50v50 | EF_POT_Euclidean_norm | 8.28 | 2500 |
| 50v50 | EF_POT_Euclidean_unnorm | 6.52 | 2500 |
| 50v50 | EF_POT_YPhi_norm | 9.28 | 2500 |
| 50v50 | Wass_Euclidean_norm | 4.70 | 2500 |
| 50v50 | Wass_Euclidean_unnorm | 7.75 | 2500 |
| 50v50 | Wass_YPhi_norm | 4.88 | 2500 |
