# Pairwise EMD Benchmark � Python (n_jobs=8)

| Split | Setup | Time (s) | Pairs |
|---|---|---|---|
| 10v90 | EF_POT_Euclidean_norm | 1.17 | 900 |
| 10v90 | EF_POT_Euclidean_unnorm | 1.04 | 900 |
| 10v90 | EF_POT_YPhi_norm | 1.28 | 900 |
| 10v90 | Wass_Euclidean_norm | 0.33 | 900 |
| 10v90 | Wass_Euclidean_unnorm | 0.61 | 900 |
| 10v90 | Wass_YPhi_norm | 0.34 | 900 |
| 50v50 | EF_POT_Euclidean_norm | 1.99 | 2500 |
| 50v50 | EF_POT_Euclidean_unnorm | 1.69 | 2500 |
| 50v50 | EF_POT_YPhi_norm | 2.16 | 2500 |
| 50v50 | Wass_Euclidean_norm | 0.79 | 2500 |
| 50v50 | Wass_Euclidean_unnorm | 1.40 | 2500 |
| 50v50 | Wass_YPhi_norm | 0.85 | 2500 |
